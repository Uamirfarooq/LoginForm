const bodyParser = require("body-parser")
const express = require("express")
const path = require("path")
const hbs = require("hbs")
const signup = require("../src/models/main")
const login = require("../src/models/main")
const { collection } = require("../src/models/main")





const app = express()
const port = 1004




const viewPath = path.join(__dirname, ('../views'))
app.set('view engine', "hbs")
app.set("views", viewPath)



app.use('/static', express.static('../public'))
app.use(bodyParser.urlencoded({
    extended: true
}))




app.get('/', (req, res) => {
    res.render('login')
})
app.get('/signup', (req, res) => {
    res.render('signup')
})
app.get('/home', (req, res) => {
    res.render('home')
})




app.post('/processSignUp', async (req, res) => {
    console.log(req.body);
    if (await collection.findOne({ email: req.body.email })) {
        res.send("the mail is already exist")
        if (await collection.findOne({ password: req.body.password })) {
            res.send("plz change the password")
        }
    }
    else {
        signup.create({
            email: req.body.email,
            password: req.body.password
        })
        res.redirect('/')
    }
})
app.post('/processLogin', async (req, res) => {
    try {
        const chk = await collection.findOne({ email: req.body.email })

        if (chk.password == req.body.password) {
            res.redirect('/home')
        }
        else {
            res.send("error");
        }
    } catch {
        res.send('there is some Problem')
    }
})





app.listen(process.env.PORT || port, () => {
    console.log(`web in running at port ${port}`);
})