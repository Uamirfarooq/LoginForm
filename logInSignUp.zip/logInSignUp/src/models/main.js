const mongoose  = require("mongoose");
mongoose.set('strictQuery', true);

mongoose.connect("mongodb://127.0.0.1:27017/helo",()=>{
    console.log("db connected");
})

const signup =mongoose.Schema({
    email:String,
    password:Number
})
module.exports=mongoose.model("signup",signup)

